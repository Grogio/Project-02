from ilMioGrafo import Node, Edge, Graph
from ilMioShortestPaths import BellmanFord, ShortestPath

def isVisible(graph, n1_id, n2_id): # O(n*m)
    """
    Ritorna True se il nodo n1 è visibile dal nodo n2
    """
    n1 = graph.getNode(n1_id)
    n2 = graph.getNode(n2_id)
    return n1 != n2 and checkVisibility(graph,n1.id, n2.id)

def checkVisibility(graph, n1_id, n2_id): # O(n*m)
    """
    Ritorna True se il nodo n1 è adiacente al nodo n2, oppure
    se n2 è connesso a n1 da un cammino minimo tale che il valore massimo M
    dei nodi intermedi, se presenti, è M <= n2.value
    """
    if graph.isAdj(n1_id, n2_id) or checkShortestPath(graph,n2_id, n1_id):
        return True
    return False

def checkShortestPath(graph, n1_id, n2_id): # O(n*m)
    """
    Ritorna True se n1 è connesso a n2 da un cammino minimo tale che il valore massimo M
    dei nodi intermedi, se presenti, è M <= n2.value
    """
    n2 = graph.getNode(n2_id)
    sPath = ShortestPath(graph, n1_id, n2_id)
    if sPath == []:
        return False
    M = 0
    i = 1
    while i <= len(sPath) - 1:
        n = sPath[i]
        if n.value > M:
            M = n.value
        i = i + 1
    if M <= n2.value:
        return True
    return False

def VisibilityDegree(graph, node_id): # O(n^2*m)
    """
    Ritorna il numero di nodi visibili da node
    """
    node = graph.getNode(node_id)
    count = 0
    nodes = graph.getNodes()
    for n in nodes:
        if isVisible(graph, n.id, node_id) == True:
            count = count + 1
    return count

def maxVisibilityDegree(graph): # O(n^3*m)
    """
    Ritorna il nodo con il massimo grado di visibilita' in graph
    """
    maxVD = 0
    nodeMaxVD = None
    i = 0
    nodes = graph.getNodes()
    while i <= len(nodes) - 1:
        n = nodes[i]
        nVD = VisibilityDegree(graph,n.id)
        if nVD > maxVD:
            maxVD = nVD
            nodeMaxVD = n
        i = i + 1
    return nodeMaxVD
    

if __name__ == "__main__":

    # INIZIALIZZA GRAFO

    graph = Graph()

    for i in range(1,10):
        graph.addNode(i,2*i)

    for t in range(1,9,2):
        graph.insertEdge(t,t+1,int(t))
        graph.insertEdge(t,t+2,int(2*t))

    graph.print()

    print("---")

    # VISIBILITA'

    print("Node1 is visible by Node1:", isVisible(graph,1,1))
    print("Node1 is visible by Node2:", isVisible(graph,1,2))
    print("Node1 is visible by Node4:", isVisible(graph,1,4))
    print("Node6 is visible by Node1:", isVisible(graph,6,1))
    print("Node9 is visible by Node7:", isVisible(graph,9,7))

    print("---")

    # GRADO DI VISIBILITA'

    for i in graph.getNodesId():
        print("Node" + str(i), "visibility degree:", VisibilityDegree(graph, i))

    print("---")
    
    # MASSIMO GRADO DI VISIBILITA'

    print("Node with max visibility degree:", maxVisibilityDegree(graph).id)
   
        
