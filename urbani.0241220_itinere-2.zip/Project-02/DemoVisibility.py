from Visibility import *
from time import time

if __name__ == "__main__":

    print("DEMO VISIBILITY GRAPH")
    print("(based on execution times only, without printing times)")
    print("---")

    # INIZIALIZZA GRAFO

    graph = Graph()

    for i in range(1,10):
        graph.addNode(i,2*i)

    for t in range(1,9,2):
        graph.insertEdge(t,t+1,int(t))
        graph.insertEdge(t,t+2,int(2*t))

    graph.print()

    print("---")

    # FUNCTION: isVisible

    print("---isVisible function Test---")

    """ n1 = n2 """
    print("n1 = n2")
    nodes = graph.getNodes()
    start = time()
    for n in nodes:
        isVisible(graph, n.id, n.id)
    elapsed = time() - start
    for n in nodes:
        print("isVisible(" + str(n.id) +"," + str(n.id) + "):", isVisible(graph, n.id, n.id))
    print("Average Time:", elapsed / len(nodes))
    print("---")

    """ n1 adj n2 """
    print("n1 adj n2")
    adjs = []
    for n1 in nodes:
        for n2 in nodes:
            if graph.isAdj(n1.id,n2.id):
                adjs = adjs + [(n1,n2)]
    start = time()
    for i in adjs:
        isVisible(graph, i[0].id, i[1].id)
    elapsed = time() - start
    for i in adjs:
        print("isVisible(" + str(i[0].id) +"," + str(i[1].id) + "):", isVisible(graph, i[0].id, i[1].id))
    print("Average Time:", elapsed / len(adjs))
    print("---")

    """ n1 not adj n2 """
    print("n1 not adj n2")
    notAdjs = []
    for n1 in nodes:
        for n2 in nodes:
            if graph.isAdj(n1.id,n2.id) == False and n1 != n2:
                notAdjs = notAdjs + [(n1,n2)]
    start = time()
    for i in notAdjs:
        isVisible(graph, i[0].id, i[1].id)
    elapsed = time() - start
    for i in notAdjs:
        print("isVisible(" + str(i[0].id) +"," + str(i[1].id) + "):", isVisible(graph, i[0].id, i[1].id))
    print("Average Time:", elapsed / len(notAdjs))
    print("---")

    # FUNCTION VisibilityDegree

    print("---VisibilityDegree function Test---")

    print("Nodes Visibility Degree:")
    start = time()
    for n in nodes:
        VisibilityDegree(graph, n.id)
    elapsed = time() - start
    for n in nodes:
        print("Node" + str(n.id) + ":", VisibilityDegree(graph, n.id))
    print("Average Time:", elapsed / len(nodes))
    print("---")

    # FUNCTION maxVisibilityDegree

    print("---maxVisibilityDegree function Test---")

    start = time()
    maxVisibilityDegree(graph).id
    elapsed = time() - start
    print("Node with max Visibility Degree:", maxVisibilityDegree(graph).id)
    print("Time:", elapsed)

    
            
        

    
