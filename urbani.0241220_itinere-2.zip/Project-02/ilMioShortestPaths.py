from ilMioGrafo import Graph

INFINITE = float("inf")

def BellmanFord(graph, root_id): # O(n*m)
    """
    Bellman-Ford's algorithm for the computation of the shortest path.
    :param graph: the graph.
    :param root: the root node to start from.
    :return: the list of distances.
    """
    nodes = graph.numNodes() # O(1)
    
    # initialize distances O(n)
    dist = {}
    for node in graph.getNodes():
        dist[node.id] = INFINITE
    dist[root_id] = 0

    # apply the relaxation step O(n*m)
    for i in range(nodes):
        for node in graph.getNodes():
            i = 0
            while i <= len(graph.incidenceList[node]) - 1:
                edge = graph.incidenceList[node][i]
                tail = edge.tail
                head = edge.head
                weight = edge.w
                # relaxation step
                if dist[tail.id] + weight < dist[head.id]:
                    dist[head.id] = dist[tail.id] + weight
                i = i + 1

    return dist

def ShortestPath(graph, n1_id, n2_id): # O(n*m)
    """
    Return the shortest path between two nodes as a list of nodes
    """
    n1 = graph.getNode(n1_id)
    n2 = graph.getNode(n2_id)
    distances = BellmanFord(graph, n1_id)
    if distances[n2_id] == INFINITE:
        return []
    path = [n2]
    curr = n2
    while curr != n1:
        for edge in graph.getEdges():
            if edge.head == curr:
                tail = edge.tail
                head = edge.head
                weight = edge.w
                if distances[tail.id] + edge.w == distances[head.id]:
                    path = [tail] + path
                    curr = tail
    return path

def printShortestPath(graph, n1_id, n2_id): # O(n*m)
    """
    Return the shortest path between two nodes as a list of nodes' id
    """
    path = ShortestPath(graph, n1_id, n2_id)
    list = []
    if path == []:
        print(str(list))
    else:
        for i in path:
            list = list + [i.id]
        print(list)


if __name__ == "__main__":

    # INIZIALIZZA GRAFO
    
    graph = Graph()

    for i in range(10):
        graph.addNode(i,2*i)

    for t in range(1,9,2):
        graph.insertEdge(t,t+1,int(t))
        graph.insertEdge(t,t+2,int(2*t))
        graph.insertEdge(t+1,t+2,int(3*t))

    graph.print()

    print("---")

    # BELLMAN-FORD

    print("BellmanFordMoore:")
    distances = BellmanFord(graph, 1)
    print("Distances (Node1):", distances)

    print("---")

    # SHORTEST PATHS

    print("Shortest path from node0 to node6:")
    printShortestPath(graph,0,6)

    print("Shortest path from node3 to node6:")
    printShortestPath(graph,3,6)

    print("Shortest path from node1 to node5:")
    printShortestPath(graph,1,5)

    print("Shortest path from node6 to node3:")
    printShortestPath(graph,6,3)

    print("Shortest path from node1 to node9:")
    printShortestPath(graph,1,9)

    
    
