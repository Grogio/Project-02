class Node:
    """
    Classe nodo
    """
    def __init__(self, id, value):
        self.id = id
        self.value = value

class Edge:
    """
    Classe arco
    """
    def __init__(self, tail, head, weight = None):
        self.tail = tail
        self.head = head
        self.w = weight

class Graph:
    """
    Classe grafo
    """
    def __init__(self, V = {}, E = {}):
        """
        Costruttore
        """
        self.incidenceList = {} #Dizionario (node, edges' list)

    def isEmpty(self): # O(1)
        """
        Ritorna True se il grafo non ha nodi
        :return: bool
        """
        return self.incidenceList == {}

    def numNodes(self): # O(1)
        """
        Ritorna il numero di nodi presenti nel grafo
        :return: int
        """
        return(len(self.incidenceList))

    def numEdges(self): # O(n)
        """
        Ritorna il numero di archi presenti nel grafo
        :return: int
        """
        count = 0
        for node in self.incidenceList.keys():
            count = count + len(self.incidenceList[node])
        return count

    def getNode(self, id): # O(n)
        """
        Ritorna il nodo (id, value)
        :return: Node
        """
        for node in self.incidenceList.keys():
            if node.id == id:
                return node

    def addNode(self, id, value): # O(n)
        """
        Aggiunge un nodo (id, value) al grafo
        Inizializza la lista di incidenza legata al nodo
        """
        node = Node(id, value)
        if self.getNode(id) != None: 
            del self.incidenceList[self.getNode(id)]
        self.incidenceList[(node)] = []

    def deleteNode(self, id): # O(n)
        """
        Elimina il nodo (id, value) dal grafo
        Elimina la lista di incidenza legata al nodo
        """
        node = self.getNode(id)
        if node != None:
            del self.incidenceList[(node)]

    def getNodes(self): # O(n)
        """
        Ritorna la lista di nodi presenti nel grafo
        :return: list of Nodes
        """
        list = []
        for node in self.incidenceList.keys():
            list.append(node)
        return list

    def getNodesId(self): # O(n)
        """
        Ritorna la lista degli id dei nodi presenti nel grafo
        :return: list of Nodes' id
        """
        list = []
        for node in self.incidenceList.keys():
            list.append(node.id)
        return list

    def insertEdge(self, tail_id, head_id, weight = None): # O(1)
        """
        Aggiunge un arco (tail, head, weight) al grafo
        Aggiunge l'arco alla lista di incidenza legata al nodo tail
        """
        tail = self.getNode(tail_id)
        head = self.getNode(head_id)
        edge = Edge(tail, head, weight)
        self.incidenceList[(tail)].append(edge)

    def getEdge(self, tail_id, head_id): # O(n + l), con l = len(incidenceList[tail])
        """
        Ritorna l'arco (tail, head, weight)
        :return: Edge
        """
        tail = self.getNode(tail_id)
        head = self.getNode(head_id)
        for edge in self.incidenceList[tail]:
            if edge.head == head:
                return edge

    def deleteEdge(self, tail_id, head_id): # O(n)
        """
        Elimina l'arco (tail, head, weight) dal grafo
        Elimina l'arco dalla lista di incidenza legata al nodo tail
        """
        tail = self.getNode(tail_id)
        edge = self.getEdge(tail_id, head_id)
        self.incidenceList[(tail)].remove(edge)

    def getEdges(self): # O(m)
        """
        Ritorna la lista degli archi presenti nel grafo
        :return: list of Edges
        """
        list = []
        for t in self.incidenceList.keys():
            for e in self.incidenceList[t]: 
                list.append(e)
        return list

    def getEdgesId(self): # O(m)
        """
        Ritorna la lista degli id degli archi presenti nel grafo
        :return: list of Edges' id
        """
        list = []
        for t in self.incidenceList.keys():
            for e in self.incidenceList[t]: 
                list.append((e.tail.id, e.head.id, e.w))
        return list

    def isAdj(self, head_id, tail_id): # O(n + l)
        """
        Ritorna True se il nodo head è adiacente a tail,
        ovvero se esiste un arco (tail, head, value)
        :return: bool
        """
        return self.getEdge(tail_id, head_id) != None

    def getAdj(self, node_id): # O(n + l)
        """
        Ritorna la lista di tutti i nodi adiacenti a node
        :return: list of Nodes
        """
        node = self.getNode(node_id)
        list = []
        for e in self.incidenceList[node]:
            if e.tail == node:
                list = list + [e.head]
        return list

    def getAdjId(self, node_id): # O(n + l)
        """
        Ritorna la lista di tutti gli id dei nodi adiacenti a node
        :return: list of Nodes' id
        """
        nodes = self.getAdj(node_id)
        list = []
        for n in nodes:
            list = list + [n.id]
        return list

    def print(self): # O(n + m)
        """
        Stampa le liste di incidenza del grafo
        """
        print("Graph's Incidence Lists:")
        for n in self.incidenceList.keys():
            node = "[" + str(n.id) + ", " + str(n.value) + "]"
            list = []
            for e in self.incidenceList[n]:
                edge = (e.tail.id, e.head.id, e.w)
                list = list + [edge] 
            print(node + " -> " + str(list))

if __name__ == "__main__":

    # INIZIALIZZA GRAFO

    graph = Graph()

    graph.print()

    print("---")

    print("The graph is empty.", graph.isEmpty())

    print("---")

    for i in range(10):
        graph.addNode(i,2*i)

    for t in range(1,9,2):
        graph.insertEdge(t,t+1,int(t))
        graph.insertEdge(t,t+2,int(2*t))
        graph.insertEdge(t+1,t+2,int(3*t))

    graph.print()

    print("---")

    print("The graph is empty.", graph.isEmpty())

    print("---")

    # METODI

    print("Graph's number of nodes:", graph.numNodes())
    print("Graph's number of edges:", graph.numEdges())
    print("---")

    print("Nodes:", graph.getNodesId())
    print("Edges:", graph.getEdgesId())
    print("---")
    
    print("Node0 = " + str(graph.getNode(0)))
    print("Node20 = " + str(graph.getNode(20)))
    print("Edge(3,5):", str(graph.getEdge(3,5)))
    print("Edge(9,5):", str(graph.getEdge(9,5)))
    print("---")
    
    print("Add Node10")
    graph.addNode(10,20)
    print("Insert Edge(0,7,0)")
    graph.insertEdge(0,7,0)
    graph.print()
    print("---")
    
    print("Delete Node10")
    graph.deleteNode(10)
    print("Delete Edge(0,7)")
    graph.deleteEdge(0,7)
    graph.print()
    print("---")

    print("Node0 is adjacent to Node2.", graph.isAdj(0,2))
    print("Node2 is adjacent to Node1.", graph.isAdj(2,1))
    print("Node3 is adjacent to Node8.", graph.isAdj(3,8))
    print("Node7 is adjacent to Node9.", graph.isAdj(7,9))
    print("Node9 is adjacent to Node7.", graph.isAdj(9,7))
    print("---")

    print("Nodes adjacent to Node5:", graph.getAdjId(5))

   
